Akshit Beat Yashi by 47 runs 
lak Beat ak by 47 runs 
lak Beat ak by 1 runs 
ak Beat ar by 33 runs 
ak Beat ar by 36 runs 
 Beat  by 25 runs 
 Beat  by 1 runs 
 Beat  by 21 runs 
 Beat  by 6 runs 
 Beat  by 1 runs 
 Beat  by 7 runs 
 Beat  by 58 runs 
ar Beat ak by 1 runs 
 Beat  by 5 runs 
 Beat  by 32 runs 
 Beat  by 4 runs 
 Beat  by 34 runs 
 Beat  by 13 runs 
 Beat  by 69 runs 
r Beat k by 7 runs 
akshit Beat arnav by 2 runs 
Draw between ak and ar
ak Beat ar by 37 runs 
 Beat  by 6 runs 
Arnav Beat Akshit by 31 runs 
Arnav Beat Akshit by 16 runs 
Arnav Beat Akshit by 5 runs 
 Beat  by 28 runs 
Ar Beat Ak by 32 runs 
Akshit Beat Arnav by 17 runs 
 Beat  by 39 runs 
Unnamed1 Beat Unnamed2 by 21 runs 
Player1 Beat Player2 by 20 runs 
Player2 Beat Player1 by 4 runs 
Player2 Beat Player1 by 13 runs 
Player1 Beat Player2 by 6 runs 
Player1 Beat Player2 by 4 runs 
Player1 Beat Player2 by 19 runs 
Player1 Beat Player2 by 25 runs 
Player2 Beat Player1 by 51 runs 
Player2 Beat Player1 by 1 runs 
Akshit Beat Arnav by 2 runs 
Arnav Beat Akshit by 32 runs 
Player2 Beat Player1 by 15 runs 
Player1 Beat Player2 by 16 runs 
Player2 Beat Player1 by 6 runs 
Player1 Beat Player2 by 6 runs 
Player1 Beat Player2 by 22 runs 
Player1 Beat Player2 by 12 runs 
Player1 Beat Player2 by 5 runs 
Player1 Beat Player2 by 24 runs 
Player2 Beat Player1 by 4 runs 
Player2 Beat Player1 by 74 runs 
Player2 Beat Player1 by 1 runs 
