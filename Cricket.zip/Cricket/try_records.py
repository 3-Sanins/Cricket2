from tkinter import *
from tkinter import messagebox
from tkinter import ttk


root=Tk()

def show_records(t1=-1,t2=-1):
    record=Frame(root)
    history=ttk.Treeview(record)
    history["columns"]=("N","R","M")
    history.column("#0",width=150,minwidth=150)
    history.column("N",width=100,minwidth=90)
    history.column("R",width=150,minwidth=150)
    history.column("M",width=150,minwidth=150)

    history.heading("#0",text="SR. no",anchor=W)
    history.heading("N",text="Name",anchor=W)
    history.heading("R",text="Runs Scored",anchor=W)
    history.heading("M",text="Matches Played",anchor=W)

    if t2==-1:
        with open("players.txt","r") as f:
            ind=1
            for player in f.readlines():
                with open(player[:len(player)-1]+"runs.txt","r") as rs:
                    try:
                        run=int(rs.read())
                    except:
                        run=5
                with open(player[:len(player)-1]+"_match.txt","r") as ms:
                    try:
                        match=int(ms.read())
                    except:
                        match=0
                history.insert("",ind-1,text=ind,values=(player,run,match))

    else:
        k=0
        for i in range(0,len(t1)):
            player1=t1[i]
            player2=t2[i]
            with open(player1+"runs.txt","r") as rs:
                try:
                    run1=int(rs.read())
                except:
                    run1=0
            with open(player1+"_match.txt","r") as ms:
                try:
                    match1=int(ms.read())
                except:
                    match1=0
            history.insert("",k,text=k+1,values=(player1,run1,match1))
            k+=1
            with open(player2+"runs.txt","r") as rs:
                try:
                    run2=int(rs.read())
                except:
                    run2=0
            with open(player2+"_match.txt","r") as ms:
                try:
                    match2=int(ms.read())
                except:
                    match2=0
            history.insert("",k,text=k+1,values=(player1,run1,match1))
            k+=1

    

    Label(record,text="Record of all the Players ").pack()
    history.pack()
    record.pack()

#show_records()

root.mainloop()
