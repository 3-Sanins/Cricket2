from tkinter import *
from tkinter import ttk
#from ttk import *

root=Tk()

t1=ttk.Treeview(root)
t1["columns"]=("R")
t1.column("#0",width=150,minwidth=150)
t1.column("R",width=100,minwidth=90)

t1.heading("#0",text="Player name",anchor=W)
t1.heading("R",text="Runs Scored",anchor=W)

t1.insert("",1,text="Akshit",values=("106"))

t1.pack(side=TOP)

t2=ttk.Treeview(root)
t2["columns"]=("R")
t2.column("#0",width=150,minwidth=150)
t2.column("R",width=100,minwidth=90)

t2.heading("#0",text="Player name",anchor=W)
t2.heading("R",text="Runs Scored",anchor=W)

t2.insert("",1,text="Akshit",values=("106"))

t2.pack(side=TOP)

root.mainloop()
